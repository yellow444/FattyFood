<?php

$smilies[':???:'] = 'confuse.png';
$smilies[':cool:'] = 'cool.png';
$smilies[':cry:'] = 'cry.png';
$smilies[':eek:'] = 'eek.png';
$smilies[':evil:'] = 'evil.png';
$smilies[':grin:'] = 'grin.png';
$smilies[':lol:'] = 'lol.png';
$smilies[':mad:'] = 'mad.png';
$smilies[':neutral:'] = 'neutral.png';
$smilies[':razz:'] = 'razz.png';
$smilies[':oops:'] = 'red.png';
$smilies[':roll:'] = 'roll.png';
$smilies[':sad:'] = 'sad.png';
$smilies[':smile:'] = 'smile.png';
$smilies[':surprise:'] = 'surprise.png';
$smilies[':twisted:'] = 'twist.png';
$smilies[':wink:'] = 'wink.png';
$smilies[':yell:'] = 'yell.png';

?>
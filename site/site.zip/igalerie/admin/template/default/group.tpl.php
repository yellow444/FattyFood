
<?php include_once(dirname(__FILE__) . '/users_submenu.tpl.php'); ?>

<?php include_once(dirname(__FILE__) . '/group_related.tpl.php'); ?>

<?php include_once(dirname(__FILE__) . '/group_infos.tpl.php'); ?>
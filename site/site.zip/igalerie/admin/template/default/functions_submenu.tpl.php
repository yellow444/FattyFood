		<h2><a href="<?php echo $tpl->getLink('functions'); ?>"><?php echo __('Gestion des fonctionnalités'); ?></a></h2>

		<div id="sub_menu_line"></div><div id="sub_menu_bg"></div>
		<h2><a href="<?php echo $tpl->getLink('pages'); ?>"><?php echo __('Gestion des pages'); ?></a></h2>

		<div id="sub_menu_line"></div><div id="sub_menu_bg"></div>

<?php
$name = 'Français';
?>
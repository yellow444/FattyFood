		<div id="gallery_404">
			<h2><?php echo __('Page non trouvée !'); ?></h2>
			<p><?php echo __('La page que vous demandez n\'existe pas,<br />ou bien vous n\'avez pas l\'autorisation d\'y accéder.'); ?></p>
			<br />
			<p><a href="<?php echo $tpl->getGallery('gallery_path'); ?>/"><?php echo __('retour à la galerie'); ?></a></p>
		</div>
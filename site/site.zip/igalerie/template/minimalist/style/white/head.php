<!--[if IE 7]><style type="text/css">@import url(<?php echo $tpl->getGallery('style_path'); ?>/white-ie7.css);</style><![endif]-->

<?php

$config['basket'] = 0;
$config['comments'] = 0;
$config['diaporama'] = 0;
$config['download_zip_albums'] = 0;
$config['exif'] = 0;
$config['geoloc'] = 0;
$config['iptc'] = 0;
$config['recent_images'] = 0;
$config['search'] = 0;
$config['search_advanced'] = 0;
$config['tags'] = 0;
$config['users'] = 0;
$config['votes'] = 0;
$config['xmp'] = 0;

$config['pages_params']['basket']['status'] = 0;
$config['pages_params']['cameras']['status'] = 0;
$config['pages_params']['comments']['status'] = 0;
$config['pages_params']['contact']['status'] = 0;
$config['pages_params']['guestbook']['status'] = 0;
$config['pages_params']['history']['status'] = 0;
$config['pages_params']['members']['status'] = 0;
$config['pages_params']['sitemap']['status'] = 0;
$config['pages_params']['tags']['status'] = 0;
$config['pages_params']['worldmap']['status'] = 0;

$config['widgets_params']['geoloc']['status'] = 0;
$config['widgets_params']['image']['status'] = 0;
$config['widgets_params']['links']['status'] = 0;
$config['widgets_params']['navigation']['status'] = 0;
$config['widgets_params']['online_users']['status'] = 0;
$config['widgets_params']['options']['status'] = 0;
$config['widgets_params']['stats_categories']['status'] = 0;
$config['widgets_params']['stats_images']['status'] = 0;
$config['widgets_params']['tags']['status'] = 0;
$config['widgets_params']['user']['status'] = 0;

$config['pages_perso'] = 0;
$config['widgets_perso'] = 0;

?>
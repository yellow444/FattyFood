
		<h2><?php echo __('Plan de la galerie'); ?></h2>

		<div id="map_list">
			<?php echo $tpl->getMap('list'); ?>

		</div>

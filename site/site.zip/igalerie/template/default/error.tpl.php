		<div id="gallery_error">
			<h2><?php echo __('Oups !'); ?></h2>
			<p class="message message_info"><?php echo __('Une erreur s\'est produite durant le traitement de votre requête.<br /><br />Vous êtes invité à signaler cette erreur à un administrateur<br />afin que le problème soit corrigé dans les plus brefs délais.'); ?></p>
			<br />
			<p><a href="<?php echo $tpl->getGallery('gallery_path'); ?>/"><?php echo __('retour à la galerie'); ?></a></p>
		</div>
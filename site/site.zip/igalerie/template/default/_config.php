<?php

$config['widgets_fixed'] = array('geoloc', 'image', 'navigation', 'stats_images', 'user');

?>
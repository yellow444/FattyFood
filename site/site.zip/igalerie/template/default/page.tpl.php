		<div id="page_content">
			<?php echo $tpl->getContent(); ?>

		</div>
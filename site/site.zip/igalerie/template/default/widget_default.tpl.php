				<div class="bottom_widget">
					<p class="title"><?php echo $tpl->getDefaultWidget('title'); ?></p>
					<?php echo $tpl->getDefaultWidget('content'); ?>

				</div>

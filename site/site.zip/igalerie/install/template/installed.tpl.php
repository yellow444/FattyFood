		<div id="content">
			<p class="icon icon_information" id="installed"><?php echo __('iGalerie est déjà installée.'); ?></p>
		</div>
